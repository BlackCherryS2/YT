package com.ytpulse.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private val Bg = Color(0xFF0B0D12)
private val Surface = Color(0xFF151820)
private val Elevated = Color(0xFF1D212B)
private val Primary = Color(0xFF8D7CFF)
private val Hot = Color(0xFFFF6B6B)
private val Muted = Color(0xFF9299AA)

data class VideoItem(val id:String,val title:String,val channel:String,val views:Long,val pulse:Int,val growth:Int,val tags:List<String>)
data class Trend(val name:String,val growth:Int,val score:Int)

data class PulseState(
    val region:String="KR", val category:String="20", val loading:Boolean=false,
    val videos:List<VideoItem> = demoVideos(), val error:String?=null
)

class PulseViewModel: ViewModel() {
    var state by mutableStateOf(PulseState()); private set
    fun refresh(region:String=state.region, category:String=state.category) {
        state = state.copy(region=region, category=category, loading=true, error=null)
        if (BuildConfig.YOUTUBE_API_KEY.isBlank()) { state=state.copy(loading=false,videos=demoVideos(),error="DEMO MODE · GitHub Secret에 YOUTUBE_API_KEY를 추가하면 실데이터로 전환됩니다."); return }
        viewModelScope.launch {
            runCatching { YouTubeApi.trending(region, category) }
                .onSuccess { state=state.copy(loading=false,videos=it) }
                .onFailure { state=state.copy(loading=false,error=it.message ?: "데이터를 불러오지 못했습니다.") }
        }
    }
}

object YouTubeApi {
    suspend fun trending(region:String, category:String):List<VideoItem> = withContext(Dispatchers.IO) {
        val q = "https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics&chart=mostPopular&maxResults=25&regionCode=${URLEncoder.encode(region,"UTF-8")}&videoCategoryId=${URLEncoder.encode(category,"UTF-8")}&key=${BuildConfig.YOUTUBE_API_KEY}"
        val c = URL(q).openConnection() as HttpURLConnection
        c.connectTimeout=10000; c.readTimeout=10000
        if(c.responseCode !in 200..299) throw IllegalStateException("YouTube API ${c.responseCode}")
        val root=JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        val arr=root.getJSONArray("items")
        (0 until arr.length()).map { i ->
            val o=arr.getJSONObject(i); val s=o.getJSONObject("snippet"); val st=o.optJSONObject("statistics")
            val views=st?.optString("viewCount")?.toLongOrNull() ?: 0
            val normalized=((kotlin.math.log10(views.coerceAtLeast(1).toDouble())-3.0)*18).toInt().coerceIn(35,99)
            VideoItem(o.getString("id"),s.getString("title"),s.getString("channelTitle"),views,normalized,(normalized-52).coerceAtLeast(8), listOf(s.optString("categoryId","Trend"),"Popular"))
        }
    }
}

fun demoVideos() = listOf(
    VideoItem("dQw4w9WgXcQ","I Tried the Impossible Challenge for 100 Hours","Creator Lab",12_800_000,96,218,listOf("Challenge","Surprise")),
    VideoItem("","The Tiny Game Everyone Suddenly Plays","Pixel Daily",8_420_000,91,171,listOf("Gaming","Curiosity")),
    VideoItem("","Street Food You Have Never Seen Before","Nomad Bite",6_910_000,87,124,listOf("Food","Discovery")),
    VideoItem("","I Built an AI Studio in One Day","Future Works",5_780_000,84,98,listOf("AI","Achievement"))
)

@Composable fun App(vm:PulseViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    var region by remember { mutableStateOf("KR") }
    var category by remember { mutableStateOf("20") }
    val wide = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp >= 700
    MaterialTheme(colorScheme=darkColorScheme(primary=Primary,background=Bg,surface=Surface)) {
        Surface(Modifier.fillMaxSize(), color=Bg) {
            Row {
                if(wide) NavRail(tab){tab=it}
                Column(Modifier.weight(1f)) {
                    AnimatedContent(tab, label="tabs") { t -> when(t){0->PulseScreen(vm,region,category,{region=it;vm.refresh(it,category)},{category=it;vm.refresh(region,it)});1->ExploreScreen(vm);2->RadarScreen();else->SavedScreen()} }
                    if(!wide) BottomNav(tab){tab=it}
                }
            }
        }
    }
}

@Composable fun Header(title:String, subtitle:String?=null) { Column(Modifier.padding(horizontal=20.dp, vertical=16.dp)){ Row(verticalAlignment=Alignment.CenterVertically){Text(title,fontSize=27.sp,fontWeight=FontWeight.Black); Spacer(Modifier.weight(1f)); Box(Modifier.size(9.dp).background(Hot,CircleShape)); Spacer(Modifier.width(7.dp)); Text("LIVE",fontSize=11.sp,color=Muted,fontWeight=FontWeight.Bold)}; subtitle?.let{Text(it,color=Muted,fontSize=13.sp)}} }

@Composable fun PulseScreen(vm:PulseViewModel, region:String, category:String,onRegion:(String)->Unit,onCategory:(String)->Unit){
    val s=vm.state
    LazyColumn(Modifier.fillMaxSize(), contentPadding=PaddingValues(bottom=22.dp)) {
        item { Header("YT PULSE","What’s moving now") }
        item { FilterRow(region,category,onRegion,onCategory) }
        item { Section("TREND PULSE"); TrendCloud() }
        item { Section("FASTEST RISING") }
        items(trends()) { TrendRow(it) }
        item { Section("AUDIENCE RESPONSE"); ResponseCard() }
        if(s.error!=null) item { Text(s.error,Modifier.padding(20.dp),color=Muted,fontSize=12.sp) }
    }
}

@Composable fun FilterRow(region:String,category:String,onRegion:(String)->Unit,onCategory:(String)->Unit){
    var regionOpen by remember{mutableStateOf(false)}; var catOpen by remember{mutableStateOf(false)}
    Row(Modifier.padding(horizontal=20.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        FilterChip(selected=true,onClick={regionOpen=true},label={Text(mapOf("KR" to "🇰🇷 Korea","US" to "🇺🇸 USA","JP" to "🇯🇵 Japan","GB" to "🇬🇧 UK")[region]?:"Global")})
        FilterChip(selected=false,onClick={catOpen=true},label={Text(mapOf("20" to "Gaming","10" to "Music","17" to "Sports","25" to "News")[category]?:"All")})
    }
    DropdownMenu(regionOpen,{regionOpen=false}) { listOf("KR","US","JP","GB").forEach{DropdownMenuItem({Text(it)},{onRegion(it);regionOpen=false})} }
    DropdownMenu(catOpen,{catOpen=false}) { listOf("20" to "Gaming","10" to "Music","17" to "Sports","25" to "News").forEach{(id,n)->DropdownMenuItem({Text(n)},{onCategory(id);catOpen=false})} }
}

@Composable fun Section(t:String)=Text(t,Modifier.padding(start=20.dp,top=24.dp,bottom=10.dp),fontSize=12.sp,color=Muted,fontWeight=FontWeight.Bold,letterSpacing=1.2.sp)
@Composable fun TrendCloud(){ Card(Modifier.padding(horizontal=20.dp).fillMaxWidth(),shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=Surface)){ Box(Modifier.fillMaxWidth().height(210.dp)){ Bubble("AI",96,Modifier.align(Alignment.Center)); Bubble("Gaming",88,Modifier.align(Alignment.CenterStart).padding(start=26.dp,bottom=60.dp)); Bubble("Minecraft",91,Modifier.align(Alignment.CenterEnd).padding(end=24.dp,top=64.dp)); Bubble("Food",71,Modifier.align(Alignment.BottomStart).padding(42.dp)); Bubble("Travel",67,Modifier.align(Alignment.TopEnd).padding(34.dp)) } } }
@Composable fun Bubble(name:String,score:Int,modifier:Modifier){ Box(modifier.size((58+score/3).dp).clip(CircleShape).background(Primary.copy(alpha=.14f)),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(name,fontWeight=FontWeight.Bold,fontSize=12.sp);Text(score.toString(),color=Primary,fontSize=11.sp)}} }
fun trends()=listOf(Trend("AI Video",284,97),Trend("Minecraft",171,94),Trend("Challenge",124,88),Trend("Street Food",91,82))
@Composable fun TrendRow(t:Trend){ Row(Modifier.padding(horizontal=20.dp,vertical=6.dp).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Surface).padding(16.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(40.dp).background(Primary.copy(.14f),CircleShape),contentAlignment=Alignment.Center){Text(t.score.toString(),color=Primary,fontWeight=FontWeight.Black)};Spacer(Modifier.width(14.dp));Text(t.name,fontWeight=FontWeight.SemiBold);Spacer(Modifier.weight(1f));Text("+${t.growth}%  ↗",color=Hot,fontWeight=FontWeight.Bold)} }
@Composable fun ResponseCard(){ Card(Modifier.padding(horizontal=20.dp).fillMaxWidth(),shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=Surface)){Column(Modifier.padding(18.dp)){listOf("😲  Surprise" to .91f,"👀  Curiosity" to .87f,"🏆  Achievement" to .79f,"😂  Humor" to .68f).forEach{(n,v)->Text(n,fontSize=13.sp);LinearProgressIndicator(v,Modifier.fillMaxWidth().padding(vertical=8.dp),color=Primary,trackColor=Elevated)}}} }

fun compactViews(value: Long): String = when {
    value >= 1_000_000_000L -> String.format("%.1fB", value / 1_000_000_000.0).replace(".0B", "B")
    value >= 1_000_000L -> String.format("%.1fM", value / 1_000_000.0).replace(".0M", "M")
    value >= 1_000L -> String.format("%.1fK", value / 1_000.0).replace(".0K", "K")
    else -> value.toString()
}

@Composable
fun ExploreScreen(vm: PulseViewModel) {
    val ctx = LocalContext.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Header(
                "EXPLORE",
                "Popular videos · ${if (BuildConfig.YOUTUBE_API_KEY.isBlank()) "Demo" else "Live"}"
            )
        }
        items(vm.state.videos) { v ->
            Card(
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 7.dp)
                    .fillMaxWidth()
                    .clickable {
                        if (v.id.isNotBlank()) {
                            ctx.startActivity(
                                Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse("https://www.youtube.com/watch?v=${v.id}")
                                )
                            )
                        }
                    },
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Surface)
            ) {
                Column(Modifier.padding(18.dp)) {
                    Row {
                        Text("🔥 ${v.pulse}", color = Hot, fontWeight = FontWeight.Black)
                        Spacer(Modifier.weight(1f))
                        Text("↗ +${v.growth}%", color = Primary, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(v.title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(v.channel, color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "${compactViews(v.views)} views  ·  ${v.tags.joinToString(" · ")}",
                        color = Muted,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable fun RadarScreen(){ LazyColumn(Modifier.fillMaxSize()){item{Header("RADAR","Signals · Global · 24H");Section("MESSAGE DNA");Card(Modifier.padding(20.dp).fillMaxWidth(),shape=RoundedCornerShape(26.dp),colors=CardDefaults.cardColors(containerColor=Surface)){Column(Modifier.padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("CURIOSITY",color=Primary,fontWeight=FontWeight.Black);Text("×",fontSize=28.sp,color=Muted);Text("CHALLENGE",fontWeight=FontWeight.Black);Text("×",fontSize=28.sp,color=Muted);Text("SURPRISE",color=Hot,fontWeight=FontWeight.Black);Spacer(Modifier.height(18.dp));Text("94",fontSize=48.sp,fontWeight=FontWeight.Black);Text("STRONG SIGNAL",color=Muted,fontSize=11.sp)}};Section("OPPORTUNITY");TrendRow(Trend("Retro Game Challenge",92,92));TrendRow(Trend("Micro Travel",87,87));TrendRow(Trend("AI ASMR",61,61))}} }
@Composable fun SavedScreen(){Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.BookmarkBorder,null,tint=Muted,modifier=Modifier.size(42.dp));Spacer(Modifier.height(12.dp));Text("Saved",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("관심 트렌드와 영상을 저장하는 공간",color=Muted)}}}

data class Nav(val label:String,val icon:ImageVector)
val navs=listOf(Nav("Pulse",Icons.Default.Bolt),Nav("Explore",Icons.Default.Explore),Nav("Radar",Icons.Default.Radar),Nav("Saved",Icons.Default.BookmarkBorder))
@Composable fun BottomNav(selected:Int,onSelect:(Int)->Unit){NavigationBar(containerColor=Surface){navs.forEachIndexed{i,n->NavigationBarItem(selected==i,{onSelect(i)},icon={Icon(n.icon,n.label)},label={Text(n.label)})}}}
@Composable fun NavRail(selected:Int,onSelect:(Int)->Unit){NavigationRail(containerColor=Surface,header={Text("YT\nPULSE",Modifier.padding(16.dp),fontWeight=FontWeight.Black,color=Primary)}){Spacer(Modifier.height(20.dp));navs.forEachIndexed{i,n->NavigationRailItem(selected==i,{onSelect(i)},icon={Icon(n.icon,n.label)},label={Text(n.label)})}}}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}
