package com.ytpulse.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.log10

private val Bg = Color(0xFF090B10)
private val Surface = Color(0xFF12151C)
private val Elevated = Color(0xFF1A1E27)
private val Primary = Color(0xFF766BFF)
private val PrimarySoft = Color(0xFFB9B4FF)
private val Hot = Color(0xFFFF4F9A)
private val Cyan = Color(0xFF45D9FF)
private val Violet = Color(0xFFA34BFF)
private val Mint = Color(0xFF65E6C4)
private val Muted = Color(0xFF9299AA)
private val Text = Color(0xFFF5F6FA)

data class VideoItem(val id:String,val title:String,val channel:String,val views:Long,val pulse:Int,val growth:Int,val tags:List<String>)
data class Trend(val name:String,val growth:Int,val score:Int)
data class Category(val id:String,val label:String,val icon:ImageVector)
data class MapSignal(val region:String,val code:String,val topic:String,val x:Float,val y:Float,val score:Int)

private val categories = listOf(
    Category("0","All",Icons.Default.AutoAwesome),
    Category("20","Gaming",Icons.Default.SportsEsports),
    Category("25","News",Icons.Default.Public),
    Category("24","Film",Icons.Default.Movie),
    Category("26","Food",Icons.Default.Restaurant),
    Category("19","Travel",Icons.Default.Flight),
    Category("10","Music",Icons.Default.MusicNote),
    Category("28","Tech",Icons.Default.Memory)
)

private val signals = listOf(
    MapSignal("Korea","KR","Gaming",.82f,.43f,96), MapSignal("Japan","JP","Anime",.87f,.43f,92),
    MapSignal("USA","US","AI",.20f,.40f,94), MapSignal("Brazil","BR","Music",.32f,.70f,88),
    MapSignal("UK","GB","Football",.48f,.35f,86), MapSignal("India","IN","Film",.70f,.52f,90),
    MapSignal("Australia","AU","Travel",.88f,.77f,81)
)

data class PulseState(val region:String="KR", val category:String="20", val loading:Boolean=false, val videos:List<VideoItem> = demoVideos(), val error:String?=null)

class PulseViewModel: ViewModel() {
    var state by mutableStateOf(PulseState()); private set
    init { refresh() }
    fun refresh(region:String=state.region, category:String=state.category) {
        state = state.copy(region=region, category=category, loading=true, error=null)
        if (BuildConfig.YOUTUBE_API_KEY.isBlank()) {
            state=state.copy(loading=false,videos=demoVideos(),error="DEMO · YOUTUBE_API_KEY를 연결하면 국가별 실시간 인기 영상으로 전환됩니다.")
            return
        }
        viewModelScope.launch {
            runCatching { YouTubeApi.trending(region, category) }
                .onSuccess { state=state.copy(loading=false,videos=it) }
                .onFailure { state=state.copy(loading=false,error=it.message ?: "데이터를 불러오지 못했습니다.") }
        }
    }
}

object YouTubeApi {
    suspend fun trending(region:String, category:String):List<VideoItem> = withContext(Dispatchers.IO) {
        val cat = if(category == "0") "" else "&videoCategoryId=${URLEncoder.encode(category,"UTF-8")}" 
        val q = "https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics&chart=mostPopular&maxResults=25&regionCode=${URLEncoder.encode(region,"UTF-8")}$cat&key=${BuildConfig.YOUTUBE_API_KEY}"
        val c = URL(q).openConnection() as HttpURLConnection
        c.connectTimeout=10000; c.readTimeout=10000
        if(c.responseCode !in 200..299) throw IllegalStateException("YouTube API ${c.responseCode}")
        val root=JSONObject(c.inputStream.bufferedReader().use { it.readText() }); val arr=root.getJSONArray("items")
        (0 until arr.length()).map { i ->
            val o=arr.getJSONObject(i); val s=o.getJSONObject("snippet"); val st=o.optJSONObject("statistics")
            val views=st?.optString("viewCount")?.toLongOrNull() ?: 0
            val normalized=((log10(views.coerceAtLeast(1).toDouble())-3.0)*18).toInt().coerceIn(35,99)
            VideoItem(o.getString("id"),s.getString("title"),s.getString("channelTitle"),views,normalized,(normalized-52).coerceAtLeast(8),listOf("Popular","${normalized} pulse"))
        }
    }
}

fun demoVideos() = listOf(
    VideoItem("dQw4w9WgXcQ","I Tried the Impossible Challenge for 100 Hours","Creator Lab",12_800_000,96,218,listOf("Challenge","Surprise")),
    VideoItem("","The Tiny Game Everyone Suddenly Plays","Pixel Daily",8_420_000,91,171,listOf("Gaming","Curiosity")),
    VideoItem("","Street Food You Have Never Seen Before","Nomad Bite",6_910_000,87,124,listOf("Food","Discovery")),
    VideoItem("","I Built an AI Studio in One Day","Future Works",5_780_000,84,98,listOf("AI","Achievement"))
)

@Composable fun App(vm:PulseViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    val wide = LocalConfiguration.current.screenWidthDp >= 700
    MaterialTheme(colorScheme=darkColorScheme(primary=Primary,background=Bg,surface=Surface,onBackground=Text,onSurface=Text)) {
        Surface(Modifier.fillMaxSize(), color=Bg) {
            Row {
                if(wide) NavRail(tab){tab=it}
                Column(Modifier.weight(1f)) {
                    AnimatedContent(tab, transitionSpec={ fadeIn(tween(260))+scaleIn(initialScale=.985f) togetherWith fadeOut(tween(180)) }, label="tabs") { t ->
                        when(t){0->PulseScreen(vm);1->ExploreScreen(vm);2->RadarScreen(vm);else->SavedScreen()}
                    }
                    if(!wide) BottomNav(tab){tab=it}
                }
            }
        }
    }
}

@Composable fun Header(title:String, subtitle:String?=null) {
    Column(Modifier.padding(horizontal=18.dp, vertical=14.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){
            Text(title,fontSize=26.sp,fontWeight=FontWeight.Black,
                color=Color.White)
            Text("✦",modifier=Modifier.padding(start=5.dp),fontSize=17.sp,color=Hot,fontWeight=FontWeight.Black)
            Spacer(Modifier.weight(1f))
            Surface(shape=RoundedCornerShape(99.dp),color=Hot.copy(.12f)){
                Row(Modifier.padding(horizontal=9.dp,vertical=5.dp),verticalAlignment=Alignment.CenterVertically){
                    Box(Modifier.size(6.dp).background(Hot,CircleShape));Spacer(Modifier.width(5.dp));Text("LIVE",fontSize=9.sp,color=Hot,fontWeight=FontWeight.Black)
                }
            }
        }
        subtitle?.let{Text(it,color=Muted,fontSize=11.sp)}
    }
}

@Composable fun PulseScreen(vm:PulseViewModel){
    val s=vm.state
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(bottom=22.dp)){
        item{Header("YT PULSE","The world, moving now")}
        item{ WorldPulseCard(s.region,{vm.refresh(it,s.category)}) }
        item{ CategoryOrb(s.category){vm.refresh(s.region,it)} }
        if(s.loading) item{LinearProgressIndicator(Modifier.padding(horizontal=18.dp).fillMaxWidth(),color=Primary,trackColor=Elevated)}
        item{Section("NOW RISING")}
        items(s.videos.take(4)){ CompactTrendCard(it) }
        item{Section("AUDIENCE SIGNAL") ; ResponseCard()}
        s.error?.let{item{Text(it,Modifier.padding(horizontal=20.dp,vertical=10.dp),color=Muted,fontSize=11.sp)}}
    }
}

@Composable fun CategoryOrb(selected:String,onSelect:(String)->Unit){
    var open by remember{mutableStateOf(false)}
    val current=categories.firstOrNull{it.id==selected}?:categories.first()
    Column(Modifier.padding(horizontal=18.dp,vertical=12.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){
            Text("CATEGORY",fontSize=10.sp,color=Muted,fontWeight=FontWeight.Bold,letterSpacing=1.3.sp);Spacer(Modifier.weight(1f));Text(current.label,color=PrimarySoft,fontSize=12.sp,fontWeight=FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(10.dp)){
            categories.forEach{c-> SquishyCategory(c,c.id==selected){onSelect(c.id)} }
        }
    }
}

@Composable fun SquishyCategory(c:Category,selected:Boolean,onClick:()->Unit){
    val scale by animateFloatAsState(if(selected)1.08f else 1f,spring(dampingRatio=.58f,stiffness=360f),label="squish")
    Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.width(62.dp)){
        Box(contentAlignment=Alignment.Center){
            if(selected) Box(Modifier.size(58.dp).background(Brush.radialGradient(listOf(Hot.copy(.45f),Primary.copy(.10f),Color.Transparent)),CircleShape))
            Surface(onClick=onClick,modifier=Modifier.size(48.dp).scale(scale),shape=CircleShape,
                color=if(selected)Color(0xFF34204C) else Elevated,
                border=if(selected) androidx.compose.foundation.BorderStroke(1.dp,Hot.copy(.75f)) else null,
                shadowElevation=if(selected)10.dp else 0.dp){
                Box(contentAlignment=Alignment.Center){Icon(c.icon,c.label,Modifier.size(21.dp),tint=if(selected)Color.White else Color(0xFFA9B0C3))}
            }
        }
        Spacer(Modifier.height(5.dp));Text(c.label,fontSize=9.sp,color=if(selected)Color.White else Muted,maxLines=1,fontWeight=if(selected)FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable fun WorldPulseCard(region:String,onRegion:(String)->Unit){
    var zoom by remember{mutableFloatStateOf(1f)}; var pan by remember{mutableStateOf(Offset.Zero)}; var selected by remember(region){mutableStateOf(signals.firstOrNull{it.code==region})}
    Card(Modifier.padding(horizontal=18.dp).fillMaxWidth(),shape=RoundedCornerShape(30.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF0B1020))){
        Column{
            Row(Modifier.padding(18.dp,16.dp,14.dp,8.dp),verticalAlignment=Alignment.CenterVertically){
                Surface(shape=CircleShape,color=Primary.copy(.16f)){Icon(Icons.Default.Public,null,Modifier.padding(8.dp).size(17.dp),tint=Cyan)}
                Spacer(Modifier.width(10.dp));Column{Text("WORLD PULSE",fontSize=10.sp,color=Color(0xFFB7C0D8),fontWeight=FontWeight.Black,letterSpacing=1.2.sp);Text(selected?.let{"${it.region} · ${it.topic}"}?:"Global signals",fontSize=16.sp,fontWeight=FontWeight.Black)}
                Spacer(Modifier.weight(1f));Surface(onClick={zoom=1f;pan=Offset.Zero},shape=CircleShape,color=Color.White.copy(.07f)){Icon(Icons.Default.CenterFocusStrong,"Reset",Modifier.padding(9.dp).size(17.dp),tint=Color.White)}
            }
            Box(Modifier.fillMaxWidth().height(255.dp).clip(RoundedCornerShape(bottomStart=30.dp,bottomEnd=30.dp)).background(Brush.radialGradient(listOf(Color(0xFF122D63),Color(0xFF081329),Color(0xFF050812))))){
                WorldMap(zoom,pan,{z,p->zoom=z;pan=p}){sig->selected=sig;onRegion(sig.code)}
                Surface(Modifier.align(Alignment.TopStart).padding(12.dp),shape=RoundedCornerShape(99.dp),color=Color(0xB3121724)){Text("◉  LIVE MAP",Modifier.padding(horizontal=10.dp,vertical=6.dp),fontSize=9.sp,color=Cyan,fontWeight=FontWeight.Bold)}
                selected?.let{sig->Surface(Modifier.align(Alignment.BottomStart).padding(12.dp),shape=RoundedCornerShape(18.dp),color=Color(0xE6161427),border=androidx.compose.foundation.BorderStroke(1.dp,Hot.copy(.25f))){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(8.dp).background(Hot,CircleShape));Spacer(Modifier.width(8.dp));Column{Text(sig.region,fontSize=9.sp,color=Muted);Text(sig.topic,fontSize=13.sp,fontWeight=FontWeight.Black)};Spacer(Modifier.width(16.dp));Text("${sig.score}",fontSize=18.sp,color=Hot,fontWeight=FontWeight.Black)}}}
                Surface(Modifier.align(Alignment.BottomEnd).padding(12.dp),shape=CircleShape,color=Color(0xB3121724)){Icon(Icons.Default.ZoomOutMap,"Map gesture",Modifier.padding(9.dp).size(17.dp),tint=Color.White)}
            }
        }
    }
}

@Composable fun WorldMap(zoom:Float,pan:Offset,onTransform:(Float,Offset)->Unit,onSignal:(MapSignal)->Unit){
    Box(Modifier.fillMaxSize().pointerInput(Unit){detectTransformGestures{_,panChange,zoomChange,_->onTransform((zoom*zoomChange).coerceIn(1f,3.5f),pan+panChange)}}){
        Canvas(Modifier.fillMaxSize()){
            val w=size.width;val h=size.height
            fun pt(x:Float,y:Float)=Offset((x*w-w/2)*zoom+w/2+pan.x,(y*h-h/2)*zoom+h/2+pan.y)
            val continent=Color(0xFF252B37);val edge=Color(0xFF353D4D)
            fun poly(points:List<Pair<Float,Float>>){val p=Path();points.forEachIndexed{i,v->val o=pt(v.first,v.second);if(i==0)p.moveTo(o.x,o.y)else p.lineTo(o.x,o.y)};p.close();drawPath(p,continent);drawPath(p,edge,style=Stroke(1.1f))}
            poly(listOf(.05f to .25f,.18f to .18f,.29f to .26f,.25f to .47f,.17f to .52f,.10f to .42f))
            poly(listOf(.25f to .52f,.36f to .55f,.39f to .78f,.32f to .94f,.27f to .72f))
            poly(listOf(.43f to .27f,.52f to .22f,.58f to .31f,.54f to .40f,.45f to .38f))
            poly(listOf(.48f to .43f,.60f to .42f,.65f to .68f,.55f to .82f,.48f to .60f))
            poly(listOf(.56f to .24f,.76f to .20f,.94f to .31f,.90f to .55f,.72f to .57f,.61f to .43f))
            poly(listOf(.80f to .70f,.94f to .69f,.96f to .84f,.84f to .87f))
            signals.forEach{s->val o=pt(s.x,s.y);val r=(6f+(s.score-75).coerceAtLeast(0)*.28f)*zoom.coerceAtMost(1.5f);val dot=when{s.score>=94->Hot;s.score>=90->Violet;else->Cyan};drawCircle(dot.copy(.10f),r*3.0f,o);drawCircle(dot.copy(.22f),r*1.9f,o);drawCircle(dot,r,o)}
        }
        signals.forEach{s->
            Box(Modifier.fillMaxSize()){Box(Modifier.align(Alignment.TopStart).offset(x=(s.x*330).dp,y=(s.y*185).dp).size(38.dp).clickable{onSignal(s)})}
        }
    }
}

@Composable fun Section(t:String)=Text(t,Modifier.padding(start=20.dp,top=22.dp,bottom=9.dp),fontSize=10.sp,color=Muted,fontWeight=FontWeight.Bold,letterSpacing=1.3.sp)
@Composable fun CompactTrendCard(v:VideoItem){
    Card(Modifier.padding(horizontal=18.dp,vertical=5.dp).fillMaxWidth(),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Surface)){
        Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Primary.copy(.28f),Hot.copy(.22f)))),contentAlignment=Alignment.Center){Text(v.pulse.toString(),color=Color.White,fontWeight=FontWeight.Black)}
            Spacer(Modifier.width(13.dp));Column(Modifier.weight(1f)){Text(v.title,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis,fontSize=13.sp);Spacer(Modifier.height(3.dp));Text(v.channel,color=Muted,fontSize=10.sp)}
            Surface(shape=RoundedCornerShape(99.dp),color=Hot.copy(.10f)){Text("▲ ${v.growth}%",Modifier.padding(horizontal=8.dp,vertical=5.dp),color=Hot,fontSize=9.sp,fontWeight=FontWeight.Black)}
        }
    }
}
@Composable fun ResponseCard(){Card(Modifier.padding(horizontal=18.dp).fillMaxWidth(),shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=Surface)){Column(Modifier.padding(17.dp)){listOf("Surprise" to .91f,"Curiosity" to .87f,"Achievement" to .79f,"Humor" to .68f).forEach{(n,v)->Row{Text(n,fontSize=11.sp);Spacer(Modifier.weight(1f));Text("${(v*100).toInt()}",fontSize=10.sp,color=Muted)};LinearProgressIndicator({v},Modifier.fillMaxWidth().padding(vertical=7.dp).height(5.dp).clip(CircleShape),color=Primary,trackColor=Elevated)}}}}

fun compactViews(value:Long):String=when{value>=1_000_000_000L->"%.1fB".format(value/1e9).replace(".0B","B");value>=1_000_000L->"%.1fM".format(value/1e6).replace(".0M","M");value>=1_000L->"%.1fK".format(value/1e3).replace(".0K","K");else->value.toString()}

@Composable fun ExploreScreen(vm:PulseViewModel){val ctx=LocalContext.current;LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(bottom=20.dp)){item{Header("EXPLORE","Popular · ${if(BuildConfig.YOUTUBE_API_KEY.isBlank())"Demo" else "Live data"}")};items(vm.state.videos){v->Card(Modifier.padding(horizontal=18.dp,vertical=6.dp).fillMaxWidth().clickable{if(v.id.isNotBlank())ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/watch?v=${v.id}")))},shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Surface)){Column(Modifier.padding(17.dp)){Row{Text("PULSE ${v.pulse}",color=Hot,fontSize=11.sp,fontWeight=FontWeight.Black);Spacer(Modifier.weight(1f));Text("↗ +${v.growth}%",color=PrimarySoft,fontSize=11.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(10.dp));Text(v.title,fontSize=16.sp,fontWeight=FontWeight.Bold);Text(v.channel,color=Muted,fontSize=11.sp);Spacer(Modifier.height(10.dp));Text("${compactViews(v.views)} views · ${v.tags.joinToString(" · ")}",color=Muted,fontSize=10.sp)}}}}}

@Composable
fun RadarScreen(vm: PulseViewModel) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Header("RADAR", "Signals · ${vm.state.region} · 24H")
            WorldPulseCard(vm.state.region) { region ->
                vm.refresh(region, vm.state.category)
            }
            Section("MESSAGE DNA")
            Card(
                modifier = Modifier.padding(horizontal = 18.dp).fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = Surface)
            ) {
                Column(
                    Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("CURIOSITY", color = PrimarySoft, fontWeight = FontWeight.Black)
                    Text("×", fontSize = 24.sp, color = Muted)
                    Text("CHALLENGE", fontWeight = FontWeight.Black)
                    Text("×", fontSize = 24.sp, color = Muted)
                    Text("SURPRISE", color = Hot, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(14.dp))
                    Text("94", fontSize = 44.sp, fontWeight = FontWeight.Black)
                    Text("STRONG SIGNAL", color = Muted, fontSize = 9.sp)
                }
            }
        }
    }
}
@Composable fun SavedScreen(){Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Surface(shape=CircleShape,color=Surface){Icon(Icons.Default.BookmarkBorder,null,tint=PrimarySoft,modifier=Modifier.padding(18.dp).size(28.dp))};Spacer(Modifier.height(12.dp));Text("Saved",fontSize=22.sp,fontWeight=FontWeight.Bold);Text("Keep signals you want to watch",color=Muted,fontSize=11.sp)}}}

data class Nav(val label:String,val icon:ImageVector)
val navs=listOf(Nav("Pulse",Icons.Default.Bolt),Nav("Explore",Icons.Default.Explore),Nav("Radar",Icons.Default.Radar),Nav("Saved",Icons.Default.BookmarkBorder))
@Composable fun BottomNav(selected:Int,onSelect:(Int)->Unit){NavigationBar(containerColor=Color(0xFF0D1018),tonalElevation=0.dp){navs.forEachIndexed{i,n->NavigationBarItem(selected==i,{onSelect(i)},icon={Icon(n.icon,n.label)},label={Text(n.label,fontSize=9.sp)},colors=NavigationBarItemDefaults.colors(indicatorColor=Hot.copy(.16f),selectedIconColor=Hot,selectedTextColor=Color.White,unselectedIconColor=Muted,unselectedTextColor=Muted))}}}
@Composable fun NavRail(selected:Int,onSelect:(Int)->Unit){NavigationRail(containerColor=Surface,header={Text("YT\nPULSE",Modifier.padding(16.dp),fontWeight=FontWeight.Black,color=PrimarySoft)}){Spacer(Modifier.height(20.dp));navs.forEachIndexed{i,n->NavigationRailItem(selected==i,{onSelect(i)},icon={Icon(n.icon,n.label)},label={Text(n.label)})}}}

class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{App()}}}
