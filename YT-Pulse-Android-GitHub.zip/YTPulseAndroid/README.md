# YT Pulse Android
Native Android MVP built with Kotlin + Jetpack Compose.

## GitHub APK build
1. Upload the CONTENTS of this folder to the repository root (do not upload only the ZIP).
2. Actions > Build YT Pulse APK > Run workflow.
3. Download `YT-Pulse-APK` from Artifacts.

The app builds and runs in Demo Mode without an API key.
For live YouTube popular-video data, add repository secret `YOUTUBE_API_KEY`.

## Local build
Requires JDK 17, Android SDK 35, and Gradle 8.9.
`gradle :app:assembleDebug`
